package com.example.mislugares10;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        // Configurar botones principales
        Button btnMostrarLugares = findViewById(R.id.btnMostrarLugares);
        Button btnPreferencias = findViewById(R.id.btnPreferencias);
        Button btnAcercaDe = findViewById(R.id.btnAcercaDe);
        Button btnSalir = findViewById(R.id.btnSalir);

        // Configurar botones de header
        ImageButton btnCorreo = findViewById(R.id.btnCorreo);
        ImageButton btnMenu = findViewById(R.id.btnMenu);

        // Configurar listeners de botones principales
        btnMostrarLugares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuPrincipal.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnPreferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuPrincipal.this, Preferencias.class);
                startActivity(intent);
            }
        });

        btnAcercaDe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuPrincipal.this, AcercaDeMejorado.class);
                startActivity(intent);
            }
        });

        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });

        // Configurar botón de correo
        btnCorreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                compartirPorCorreo();
            }
        });

        // Configurar botón de menú (tres puntos)
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarMenuPopup(v);
            }
        });
    }

    private void compartirPorCorreo() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("message/rfc822");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{""});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Mis Lugares - Recomendación");
        intent.putExtra(Intent.EXTRA_TEXT, "Te recomiendo la aplicación Mis Lugares para gestionar tus lugares favoritos!");

        try {
            startActivity(Intent.createChooser(intent, "Enviar correo..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "No hay clientes de correo instalados.", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarMenuPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.getMenuInflater().inflate(R.menu.menu_principal_popup, popup.getMenu());

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.menu_buscar) {
                    lanzarBuscarLugar();
                    return true;
                } else if (id == R.id.menu_acerca_de) {
                    Intent intent = new Intent(MenuPrincipal.this, AcercaDeMejorado.class);
                    startActivity(intent);
                    return true;
                } else if (id == R.id.menu_preferencias) {
                    Intent intent = new Intent(MenuPrincipal.this, Preferencias.class);
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        popup.show();
    }
    private void lanzarBuscarLugar() {
        final EditText entrada = new EditText(this);
        entrada.setText("0");
        entrada.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        new AlertDialog.Builder(this)
                .setTitle("Buscar Lugar")
                .setMessage("Ingresa el ID del lugar que quieres ver:")
                .setView(entrada)
                .setPositiveButton("Buscar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int whichButton) {
                        try {
                            long id = Long.parseLong(entrada.getText().toString());

                            // Verificar si el lugar existe
                            if (!Lugares.existeLugar((int) id)) {
                                Toast.makeText(MenuPrincipal.this,
                                        "Error: No existe un lugar con ID " + id,
                                        Toast.LENGTH_LONG).show();
                                return;
                            }

                            // Abrir VistaLugar con el ID especificado
                            Intent i = new Intent(MenuPrincipal.this, VistaLugar.class);
                            i.putExtra("id", id);
                            startActivity(i);

                        } catch (NumberFormatException e) {
                            Toast.makeText(MenuPrincipal.this,
                                    "Error: ID debe ser un número válido",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}