package com.example.mislugares10;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class Lugares {
    final static String TAG = "MisLugares";
    protected static GeoPunto posicionActual = new GeoPunto(0,0);
    protected static List<Lugar> vectorLugares = ejemploLugares();
    private static Context context; // Añadir contexto estático

    public Lugares(){
        vectorLugares = ejemploLugares();
    }

    // Método para inicializar el contexto
    public static void setContext(Context ctx) {
        context = ctx;
    }

    public static Lugar elemento(int id){
        Log.d("Lugares", "Buscando elemento - ID: " + id);

        Lugar lugar = null;

        // CORRECCIÓN: Crear instancia de LugaresDB
        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * from lugares WHERE _id = ?",
                new String[]{String.valueOf(id)});

        if(cursor.moveToNext()){
            Log.d("Lugares", "Elemento encontrado - ID: " + id);
            lugar = new Lugar();

            lugar.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("nombre")));
            lugar.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("direccion")));

            double longitud = cursor.getDouble(cursor.getColumnIndexOrThrow("longitud"));
            double latitud = cursor.getDouble(cursor.getColumnIndexOrThrow("latitud"));
            lugar.setPosicion(new GeoPunto(longitud, latitud));

            lugar.setTipo(TipoLugar.values()[cursor.getInt(cursor.getColumnIndexOrThrow("tipo"))]);
            lugar.setFoto(cursor.getString(cursor.getColumnIndexOrThrow("foto")));
            lugar.setTelefono(cursor.getInt(cursor.getColumnIndexOrThrow("telefono")));
            lugar.setUrl(cursor.getString(cursor.getColumnIndexOrThrow("url")));
            lugar.setComentario(cursor.getString(cursor.getColumnIndexOrThrow("comentario")));
            lugar.setFecha(cursor.getLong(cursor.getColumnIndexOrThrow("fecha")));
            lugar.setValoracion(cursor.getFloat(cursor.getColumnIndexOrThrow("valoracion")));
        } else {
            Log.e("Lugares", "Elemento NO encontrado - ID: " + id);
        }

        cursor.close();
        db.close();
        return lugar;
    }

    public static void actualizarLugar(int id, Lugar lugar){
        try {
            // CORRECCIÓN: Crear instancia de LugaresDB
            LugaresDB dbHelper = new LugaresDB(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            // Usar ContentValues para una actualización más segura
            ContentValues valores = new ContentValues();
            valores.put("nombre", lugar.getNombre());
            valores.put("direccion", lugar.getDireccion());
            valores.put("longitud", lugar.getPosicion().getLongitud());
            valores.put("latitud", lugar.getPosicion().getLatitud());
            valores.put("tipo", lugar.getTipo().ordinal());
            valores.put("foto", lugar.getFoto());
            valores.put("telefono", lugar.getTelefono());
            valores.put("url", lugar.getUrl());
            valores.put("comentario", lugar.getComentario());
            valores.put("fecha", lugar.getFecha());
            valores.put("valoracion", lugar.getValoracion());

            int filasAfectadas = db.update("lugares", valores, "_id = ?",
                    new String[]{String.valueOf(id)});

            db.close();

            if (filasAfectadas > 0) {
                Log.d("Lugares", "Lugar actualizado exitosamente - ID: " + id);
            } else {
                Log.e("Lugares", "No se pudo actualizar el lugar - ID: " + id);
            }
        } catch (Exception e) {
            Log.e("Lugares", "Error al actualizar lugar: " + e.getMessage());
            e.printStackTrace();
        }
    }

    static void anyade(Lugar lugar){
        vectorLugares.add(lugar);
    }

    public static int nuevo(){
        int id = -1;
        Lugar lugar = new Lugar();

        try {
            LugaresDB dbHelper = new LugaresDB(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues valores = new ContentValues();
            valores.put("longitud", lugar.getPosicion().getLongitud());
            valores.put("latitud", lugar.getPosicion().getLatitud());
            valores.put("tipo", lugar.getTipo().ordinal());
            valores.put("fecha", lugar.getFecha());

            // Insertar y obtener el ID
            long newRowId = db.insert("lugares", null, valores);

            if (newRowId != -1) {
                id = (int) newRowId;
                Log.d("Lugares", "Nuevo lugar creado con ID: " + id);
            } else {
                Log.e("Lugares", "Error al crear nuevo lugar");
            }

            db.close();

        } catch (Exception e) {
            Log.e("Lugares", "Error en método nuevo(): " + e.getMessage());
        }

        return id;
    }

    public static void borrar(int id) {
        Log.d("Lugares", "Ejecutando borrado - ID: " + id);

        if (id < 0) {
            Log.e("Lugares", "ID inválido para borrar: " + id);
            return;
        }

        try {
            // CORRECCIÓN: Crear instancia de LugaresDB
            LugaresDB dbHelper = new LugaresDB(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            int filasAfectadas = db.delete("lugares", "_id = ?",
                    new String[]{String.valueOf(id)});
            db.close();

            Log.d("Lugares", "Filas afectadas al borrar: " + filasAfectadas);

            if (filasAfectadas == 0) {
                Log.e("Lugares", "No se encontró el lugar con ID: " + id);
            } else {
                Log.d("Lugares", "Lugar borrado exitosamente - ID: " + id);

                // NOTIFICAR CAMBIOS EN LA BASE DE DATOS
                // Esto asegura que los cursores se actualicen
            }
        } catch (Exception e) {
            Log.e("Lugares", "Error al borrar lugar: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static int size() {
        return vectorLugares.size();
    }

    public static ArrayList<Lugar> ejemploLugares(){
        ArrayList<Lugar> lugares = new ArrayList<Lugar>();
        lugares.add(new Lugar("Escuela Politécnica Superior de Gandía",
                "C/ Paranimf, 1 46730 Gandia (SPAIN)", -0.166093, 38.995656,
                TipoLugar.EDUCACION, 962849300, "http://www.epsg.upv.es",
                "Uno de los mejores lugares para formarse.", 3));
        lugares.add(new Lugar("El Chañar","Ruta Prov. 228",
                -64.5404009,-32.0672181,TipoLugar.RESTAURANTE,515273,
                "https://www.elchanar.com.ar","Un gran lugar para comer",3));
        lugares.add(new Lugar("Al de siempre",
                "P.Industrial Junto Molí Nou - 46722, Benifla (Valencia)",
                -0.190642, 38.925857, TipoLugar.BAR, 636472405,
                "", "No te pierdas el arroz en calabaza.", 3));
        lugares.add(new Lugar("Barranco del Infierno",
                "Vía Verde del rio Serpis. Villalonga (Valencia)",
                -0.295058, 38.867180, TipoLugar.NATURALEZA, 0,
                "http://eosegaos.blogspot.com.es/2009/02/1orcha-villalonga-via-verde-del-rio.html",
                "Espectacular ruta para bici o andar", 4));
        lugares.add(new Lugar("La Vital",
                "Avda. La Vital, 0 46701 Gandia (Valencia)", -0.1720092,
                38.9705949, TipoLugar.COMPRAS, 962881070,
                "http://www.lavital.es/", "El típico centro comercial", 2));
        lugares.add(new Lugar("androidcurso.com", "ciberespacio",
                0.0, 0.0, TipoLugar.EDUCACION,
                962849300, "http://androidcurso.com",
                "Amplía tus conocimientos sobre Android.", 5));
        return lugares;
    }

    private static LugaresDB lugaresDB;

    public static void inicializaDB(Context contexto){
        context = contexto; // Guardar el contexto
        lugaresDB = new LugaresDB(contexto);
    }

    public static Cursor listado(){
        // CORRECCIÓN: Crear instancia de LugaresDB
        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        return db.rawQuery("SELECT * FROM lugares",null);
    }

    public static int buscarNombre(String nombre){
        int id = -1;

        // CORRECCIÓN: Crear instancia de LugaresDB
        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM lugares WHERE nombre = '"
                + nombre + "'",null);
        if(c.moveToNext()){
            id = c.getInt(0);
        }
        c.close();
        db.close();
        return id;
    }

    public static int primerId(){
        int id = -1;

        // CORRECCIÓN: Crear instancia de LugaresDB
        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT _id FROM lugares ORDER BY _id asc LIMIT 1 ",
                null);
        if (c.moveToNext()) {
            id = c.getInt(0);
        }
        c.close();
        db.close();
        return id;
    }

    public static boolean existeLugar(int id) {
        if (id < 0) return false;

        // CORRECCIÓN: Crear instancia de LugaresDB
        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = null;
        boolean existe = false;

        try {
            cursor = db.rawQuery("SELECT _id FROM lugares WHERE _id = ?",
                    new String[]{String.valueOf(id)});
            existe = (cursor != null && cursor.moveToFirst());
        } catch (Exception e) {
            Log.e("Lugares", "Error al verificar existencia: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        Log.d("Lugares", "Verificación existencia ID " + id + ": " + existe);
        return existe;
    }
}