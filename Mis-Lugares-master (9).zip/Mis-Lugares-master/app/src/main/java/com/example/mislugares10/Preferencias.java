package com.example.mislugares10;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Preferencias extends AppCompatActivity {

    private TextView tvCriterioSeleccionado;
    private TextView tvMaximoLugares;
    private Switch switchMandarNotificaciones;
    private String criterioActual = "Creación"; // Valor por defecto
    private int maximoLugares = 12; // Valor por defecto
    private boolean mandarNotificaciones = false; // Valor por defecto
    private SharedPreferences prefs;
    private LinearLayout layoutNotificacionesCorreo;

    // Constantes para los criterios
    private static final String CRITERIO_CREACION = "Creación";
    private static final String CRITERIO_VALORACION = "Valoración";
    private static final String CRITERIO_DISTANCIA = "Distancia";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferencias);

        // Configurar toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Habilitar botón de retroceso
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Inicializar SharedPreferences
        prefs = getSharedPreferences("MisPreferencias", MODE_PRIVATE);

        // Cargar preferencias guardadas
        criterioActual = prefs.getString("criterio_ordenacion", CRITERIO_CREACION);
        maximoLugares = prefs.getInt("maximo_lugares", 12);
        mandarNotificaciones = prefs.getBoolean("mandar_notificaciones", false);

        // Referenciar vistas
        tvCriterioSeleccionado = findViewById(R.id.tvCriterioSeleccionado);
        tvMaximoLugares = findViewById(R.id.tvMaximoLugares);
        switchMandarNotificaciones = findViewById(R.id.switchMandarNotificaciones);
        LinearLayout layoutCriterio = findViewById(R.id.layoutCriterioOrdenacion);
        LinearLayout layoutMaximoLugares = findViewById(R.id.layoutMaximoLugares);
        layoutNotificacionesCorreo = findViewById(R.id.layoutNotificacionesCorreo);

        // Mostrar valores actuales
        tvCriterioSeleccionado.setText(criterioActual);
        tvMaximoLugares.setText(String.valueOf(maximoLugares));
        switchMandarNotificaciones.setChecked(mandarNotificaciones);

        // Configurar listener para "Mandar notificaciones"
        switchMandarNotificaciones.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mandarNotificaciones = isChecked;
            guardarPreferenciaMandarNotificaciones(isChecked);
        });

        // Configurar click listener para el criterio de ordenación
        layoutCriterio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoCriterios();
            }
        });

        // Configurar click listener para el máximo de lugares
        layoutMaximoLugares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoMaximoLugares();
            }
        });

        // Configurar click listener para notificaciones por correo
        layoutNotificacionesCorreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarNotificacionesCorreo();
            }
        });
    }

    private void guardarPreferenciaMandarNotificaciones(boolean mandar) {
        mandarNotificaciones = mandar;
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("mandar_notificaciones", mandar);
        editor.apply();

        Toast.makeText(Preferencias.this,
                mandar ? "Notificaciones activadas" : "Notificaciones desactivadas",
                Toast.LENGTH_SHORT).show();
    }

    private void lanzarNotificacionesCorreo() {
        Intent intent = new Intent(Preferencias.this, NotificacionesCorreo.class);
        startActivity(intent);
    }

    private void mostrarDialogoMaximoLugares() {
        final EditText entrada = new EditText(this);
        entrada.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        entrada.setText(String.valueOf(maximoLugares));
        entrada.setSelection(entrada.getText().length()); // Colocar cursor al final

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Máximo de lugares a mostrar");
        builder.setMessage("Limita el número de valores que se muestran en la lista");
        builder.setView(entrada);

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    int nuevoMaximo = Integer.parseInt(entrada.getText().toString());

                    // Validar que sea un número positivo
                    if (nuevoMaximo > 0) {
                        maximoLugares = nuevoMaximo;
                        tvMaximoLugares.setText(String.valueOf(maximoLugares));

                        // Guardar en SharedPreferences
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putInt("maximo_lugares", maximoLugares);
                        editor.apply();

                        Toast.makeText(Preferencias.this,
                                "Máximo de lugares establecido en: " + maximoLugares,
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Preferencias.this,
                                "El número debe ser mayor a 0",
                                Toast.LENGTH_SHORT).show();
                    }

                } catch (NumberFormatException e) {
                    Toast.makeText(Preferencias.this,
                            "Por favor ingresa un número válido",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void mostrarDialogoCriterios() {
        // Array con las opciones
        final String[] opciones = {CRITERIO_CREACION, CRITERIO_VALORACION, CRITERIO_DISTANCIA};

        // Encontrar qué opción está seleccionada actualmente
        int seleccionado = 0;
        for (int i = 0; i < opciones.length; i++) {
            if (opciones[i].equals(criterioActual)) {
                seleccionado = i;
                break;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Criterio de ordenación");
        builder.setSingleChoiceItems(opciones, seleccionado, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Actualizar criterio seleccionado
                criterioActual = opciones[which];
                tvCriterioSeleccionado.setText(criterioActual);

                // Guardar en SharedPreferences
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("criterio_ordenacion", criterioActual);
                editor.apply();

                // Mostrar mensaje de confirmación
                Toast.makeText(Preferencias.this,
                        "Ordenación por: " + criterioActual,
                        Toast.LENGTH_SHORT).show();

                // Cerrar diálogo
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Método para obtener el criterio actual (puede ser usado desde otras actividades)
    public static String getCriterioOrdenacion(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        return prefs.getString("criterio_ordenacion", CRITERIO_CREACION);
    }

    // Método para obtener el máximo de lugares (puede ser usado desde otras actividades)
    public static int getMaximoLugares(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        return prefs.getInt("maximo_lugares", 12); // Valor por defecto: 12
    }

    // Método para obtener si se deben mandar notificaciones
    public static boolean getMandarNotificaciones(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        return prefs.getBoolean("mandar_notificaciones", false); // Valor por defecto: false
    }
}