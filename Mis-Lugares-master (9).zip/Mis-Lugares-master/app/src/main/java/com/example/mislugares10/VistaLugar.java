package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class VistaLugar extends AppCompatActivity {

    private long id;
    private Lugar lugar;
    private ImageView imageview;

    // CORREGIR: Usar códigos únicos
    final static int RESULTADO_EDITAR = 1234;  // Ya lo estás usando
    final static int RESULTADO_GALERIA = 1235;
    final static int RESULTADO_FOTO = 1236;

    private Uri uriFoto;

    @Override
    protected void onCreate(Bundle savedInstancestate) {
        super.onCreate(savedInstancestate);
        setContentView(R.layout.vista_lugar);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            id = extras.getLong("id", -1);

            // VERIFICAR MÁS DETALLADAMENTE
            if (id == -1) {
                Log.e("VistaLugar", "ID inválido recibido");
                Toast.makeText(this, "Error: ID inválido", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // VERIFICAR SI EL LUGAR EXISTE EN LA BD
            if (!Lugares.existeLugar((int) id)) {
                Log.e("VistaLugar", "Lugar no existe en BD - ID: " + id);
                Toast.makeText(this, "Error: Lugar no encontrado", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            lugar = Lugares.elemento((int) id);
            if (lugar == null) {
                Log.e("VistaLugar", "No se pudo cargar el lugar - ID: " + id);
                Toast.makeText(this, "Error al cargar el lugar", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

        } else {
            Log.e("VistaLugar", "No se recibieron extras");
            Toast.makeText(this, "Error: No se recibió ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        imageview = (ImageView) findViewById(R.id.foto);
        actualizarVistas();
    }

    public void actualizarVistas(){
        lugar = Lugares.elemento((int) id);
        TextView nombre = findViewById(R.id.nombre);
        nombre.setText(lugar.getNombre());
        ImageView logo_tipo = findViewById(R.id.logo_tipo);
        logo_tipo.setImageResource(lugar.getTipo().getRecurso());
        TextView tipo = findViewById(R.id.tipo);
        tipo.setText(lugar.getTipo().getTexto());
        TextView direccion = findViewById(R.id.direccion);
        direccion.setText(lugar.getDireccion());
        TextView telefono = findViewById(R.id.telefono);
        telefono.setText(Integer.toString(lugar.getTelefono()));
        TextView url = findViewById(R.id.url);
        url.setText(lugar.getUrl());
        TextView comentario = findViewById(R.id.comentario);
        comentario.setText(lugar.getComentario());
        TextView fecha = findViewById(R.id.fecha);
        fecha.setText(DateFormat.getDateInstance().format(
                new Date(lugar.getFecha())));
        TextView hora = findViewById(R.id.hora);
        hora.setText(DateFormat.getTimeInstance().format(
                new Date(lugar.getFecha())));
        RatingBar valoracion = findViewById(R.id.valoracion);
        valoracion.setRating(lugar.getValoracion());
        valoracion.setOnRatingBarChangeListener(
                new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar,
                                                float valor, boolean fromUser) {
                        lugar.setValoracion(valor);
                        Lugares.actualizarLugar((int) id, lugar);
                    }
                }
        );
        ponerFoto(imageview, lugar.getFoto());
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_vista_lugar, menu);
        return true;
    }

    public void lanzarBorrar() {
        Log.d("VistaLugar", "Iniciando borrado - ID: " + id); // ← AÑADIR ESTA LÍNEA

        new AlertDialog.Builder(this)
                .setTitle("Borrado de lugar")
                .setMessage("¿Estás seguro de querer eliminar este lugar?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int cualBoton) {
                        Log.d("VistaLugar", "Confirmado borrado - ID: " + id); // ← AÑADIR ESTA LÍNEA
                        if (id >= 0) {
                            Lugares.borrar((int) id);
                            finish();
                        } else {
                            Log.e("VistaLugar", "ID inválido: " + id); // ← AÑADIR ESTA LÍNEA
                            Toast.makeText(VistaLugar.this, "ID inválido", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public void lanzarEditarLugar(){
        Intent i = new Intent(VistaLugar.this, EdicionLugar.class);
        i.putExtra("id", id);
        startActivityForResult(i, 1234);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("VistaLugar", "onActivityResult - request: " + requestCode + ", result: " + resultCode + ", data: " + data);

        // Constantes para mejor legibilidad (deberían estar definidas en la clase)
        final int RESULTADO_EDITAR = 1234;
        final int RESULTADO_FOTO = 1003;
        final int RESULTADO_GALERIA = 1002;

        if (requestCode == RESULTADO_EDITAR) {
            // Para edición
            actualizarVistas();
            findViewById(R.id.scrollView1).invalidate();
            Log.d("VistaLugar", "Edición completada - vistas actualizadas");

        } else if (requestCode == RESULTADO_FOTO) {
            // Para foto de cámara
            if (resultCode == Activity.RESULT_OK) {
                Log.d("VistaLugar", "Foto tomada exitosamente - URI: " + uriFoto);

                if (lugar != null && uriFoto != null) {
                    try {
                        lugar.setFoto(uriFoto.toString());
                        Lugares.actualizarLugar((int) id, lugar);
                        ponerFoto(imageview, lugar.getFoto());
                        Toast.makeText(this, "Foto guardada correctamente", Toast.LENGTH_SHORT).show();
                        Log.d("VistaLugar", "Foto guardada en la base de datos");
                    } catch (Exception e) {
                        Log.e("VistaLugar", "Error al guardar foto: " + e.getMessage());
                        Toast.makeText(this, "Error al guardar la foto", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Log.e("VistaLugar", "Error: lugar o uriFoto son nulos");
                    Toast.makeText(this, "Error al procesar la foto", Toast.LENGTH_SHORT).show();
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.d("VistaLugar", "Usuario canceló la toma de foto");
                Toast.makeText(this, "Foto cancelada", Toast.LENGTH_SHORT).show();
            }

        } else if (requestCode == RESULTADO_GALERIA) {
            // Para galería
            if (resultCode == Activity.RESULT_OK && data != null) {
                Uri imagenUri = data.getData();
                Log.d("VistaLugar", "Imagen seleccionada de galería - URI: " + imagenUri);

                if (imagenUri != null && lugar != null) {
                    try {
                        // Obtener permisos de lectura persistentes (para Android 10+)
                        final int takeFlags = data.getFlags() &
                                (Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                        getContentResolver().takePersistableUriPermission(imagenUri, takeFlags);

                        // Guardar la URI de la imagen
                        lugar.setFoto(imagenUri.toString());
                        Lugares.actualizarLugar((int) id, lugar);
                        ponerFoto(imageview, lugar.getFoto());

                        Toast.makeText(this, "Imagen seleccionada correctamente", Toast.LENGTH_SHORT).show();
                        Log.d("VistaLugar", "Imagen de galería guardada en base de datos");

                    } catch (SecurityException e) {
                        Log.e("VistaLugar", "Error de permisos para la imagen: " + e.getMessage());
                        Toast.makeText(this, "Error de permisos para leer la imagen", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Log.e("VistaLugar", "Error al procesar imagen de galería: " + e.getMessage());
                        Toast.makeText(this, "Error al procesar la imagen", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Log.e("VistaLugar", "URI de imagen nula o lugar nulo");
                    Toast.makeText(this, "Error al obtener la imagen", Toast.LENGTH_SHORT).show();
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.d("VistaLugar", "Usuario canceló la selección de galería");
            } else {
                Log.e("VistaLugar", "Resultado inesperado de galería: " + resultCode);
            }
        } else {
            // Para cualquier otro requestCode no manejado
            Log.w("VistaLugar", "RequestCode no manejado: " + requestCode);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int idItem = item.getItemId();

        if (idItem == R.id.accion_compartir) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT,
                    lugar.getNombre() + " - " + lugar.getUrl());
            startActivity(intent);
            return true;

        } else if (idItem == R.id.accion_llegar) {
            verMapa(null);
            return true;

        } else if (idItem == R.id.accion_borrar) {
            lanzarBorrar();
            return true;

        } else if (idItem == R.id.accion_editar) {
            lanzarEditarLugar();
            return true;

        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    public void verMapa(View view){
        // Mostrar diálogo para seleccionar lugar por ID
        final EditText entrada = new EditText(this);
        entrada.setText("0");
        entrada.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        new AlertDialog.Builder(this)
                .setTitle("Navegar a lugar")
                .setMessage("Ingresa el ID del lugar al que quieres ir:")
                .setView(entrada)
                .setPositiveButton("Ir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int whichButton) {
                        try {
                            long idDestino = Long.parseLong(entrada.getText().toString());

                            // Verificar si el lugar existe
                            if (!Lugares.existeLugar((int) idDestino)) {
                                Toast.makeText(VistaLugar.this,
                                        "Error: No existe un lugar con ID " + idDestino,
                                        Toast.LENGTH_LONG).show();
                                return;
                            }

                            // Obtener el lugar destino
                            Lugar lugarDestino = Lugares.elemento((int) idDestino);
                            if (lugarDestino != null) {
                                abrirMapaConDestino(lugarDestino);
                            }

                        } catch (NumberFormatException e) {
                            Toast.makeText(VistaLugar.this,
                                    "Error: ID debe ser un número válido",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // Nuevo método para abrir el mapa con el destino específico
    private void abrirMapaConDestino(Lugar lugarDestino) {
        Uri uri;
        double lat = lugarDestino.getPosicion().getLatitud();
        double lon = lugarDestino.getPosicion().getLongitud();

        if (lat != 0 || lon != 0) {
            // Si tiene coordenadas, usar navegación directa
            uri = Uri.parse("google.navigation:q=" + lat + "," + lon);
            // Alternativa: uri = Uri.parse("geo:" + lat + "," + lon + "?q=" + lat + "," + lon);
        } else if (lugarDestino.getDireccion() != null && !lugarDestino.getDireccion().isEmpty()) {
            // Si no tiene coordenadas pero tiene dirección, buscar por dirección
            uri = Uri.parse("google.navigation:q=" + Uri.encode(lugarDestino.getDireccion()));
        } else {
            Toast.makeText(this,
                    "Este lugar no tiene ubicación definida",
                    Toast.LENGTH_LONG).show();
            return;
        }

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps"); // Forzar a usar Google Maps

        // Verificar si Google Maps está disponible
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            // Si no está Google Maps, intentar con cualquier app de mapas
            intent.setPackage(null);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            } else {
                Toast.makeText(this,
                        "No hay aplicaciones de mapas instaladas",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    public void llamadaTelefono(View view){
        startActivity(new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:" + lugar.getTelefono())));
    }

    public void paginaWeb(View view){
        startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse(lugar.getUrl())));
    }

    public void galeria(View view){
        try {
            // USAR ACTION_PICK en lugar de ACTION_GET_CONTENT para mejor compatibilidad
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");

            // Verificar que hay una app para manejar la galería
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(Intent.createChooser(intent, "Seleccionar imagen"), RESULTADO_GALERIA);
            } else {
                // Si no hay app de galería, intentar con ACTION_GET_CONTENT
                Intent intentAlternativo = new Intent(Intent.ACTION_GET_CONTENT);
                intentAlternativo.setType("image/*");
                intentAlternativo.addCategory(Intent.CATEGORY_OPENABLE);

                if (intentAlternativo.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(Intent.createChooser(intentAlternativo, "Seleccionar imagen"), RESULTADO_GALERIA);
                } else {
                    Toast.makeText(this, "No hay app de galería disponible", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            Log.e("VistaLugar", "Error al abrir galería: " + e.getMessage());
            Toast.makeText(this, "Error al acceder a la galería: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    protected void ponerFoto(ImageView imageview, String uri){
        if (uri != null && !uri.isEmpty()) {
            try {
                // Verificar si es una URI de contenido
                if (uri.startsWith("content://") || uri.startsWith("file://")) {
                    Bitmap bitmap = reduceBitmap(this, uri, 1024, 1024);
                    if (bitmap != null) {
                        imageview.setImageBitmap(bitmap);
                        Log.d("VistaLugar", "Imagen cargada exitosamente: " + uri);
                    } else {
                        imageview.setImageResource(R.drawable.otros);
                        Log.e("VistaLugar", "No se pudo cargar la imagen: " + uri);
                    }
                } else {
                    // Si no es una URI válida, usar imagen por defecto
                    imageview.setImageResource(R.drawable.otros);
                    Log.e("VistaLugar", "URI de imagen no válida: " + uri);
                }
            } catch (Exception e) {
                imageview.setImageResource(R.drawable.otros);
                Log.e("VistaLugar", "Error al cargar imagen: " + e.getMessage());
            }
        } else {
            imageview.setImageBitmap(null);
            Log.d("VistaLugar", "No hay imagen para mostrar");
        }
    }

    public void tomarFoto(View view) {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            // Verificar disponibilidad de cámara de manera más robusta
            List<ResolveInfo> activities = getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);

            if (activities.isEmpty()) {
                // No hay app de cámara disponible
                mostrarAlternativasCamara();
                return;
            }

            // Crear directorio para fotos
            File directorioFotos = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (directorioFotos == null || (!directorioFotos.exists() && !directorioFotos.mkdirs())) {
                Toast.makeText(this, "Error creando directorio de fotos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Crear archivo con nombre único
            String timestamp = String.valueOf(System.currentTimeMillis());
            File fotoArchivo = new File(directorioFotos, "img_" + id + "_" + timestamp + ".jpg");

            // Obtener URI usando FileProvider
            uriFoto = FileProvider.getUriForFile(this,
                    getApplicationContext().getPackageName() + ".provider",
                    fotoArchivo);

            Log.d("VistaLugar", "URI de foto: " + uriFoto.toString());
            Log.d("VistaLugar", "Archivo: " + fotoArchivo.getAbsolutePath());

            // Configurar intent con permisos
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFoto);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            // Otorgar permisos temporales a todas las apps que puedan manejar la cámara
            for (ResolveInfo activity : activities) {
                grantUriPermission(activity.activityInfo.packageName, uriFoto,
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }

            // Iniciar actividad de cámara
            startActivityForResult(intent, RESULTADO_FOTO);

        } catch (Exception e) {
            Log.e("VistaLugar", "Error al tomar foto: " + e.getMessage(), e);
            Toast.makeText(this, "Error al acceder a la cámara: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // Método para mostrar alternativas cuando no hay cámara
    private void mostrarAlternativasCamara() {
        new AlertDialog.Builder(this)
                .setTitle("Cámara no disponible")
                .setMessage("No se encontró una aplicación de cámara en tu dispositivo. ¿Qué te gustaría hacer?")
                .setPositiveButton("Usar Galería", (dialog, which) -> {
                    galeria(null);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public void eliminarFoto(View view){
        new AlertDialog.Builder(this)
                .setTitle("Eliminacion de foto")
                .setMessage("Estas seguro?")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int cualBoton) {
                        lugar.setFoto(null);
                        Lugares.actualizarLugar((int) id, lugar);
                        ponerFoto(imageview,null);
                    }
                })
                .setNegativeButton("Cancelar",null)
                .show();
    }

    public static Bitmap reduceBitmap(Context contexto, String uri,
                                      int MaxAncho, int MaxAlto){
        try{
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)),null,options);
            options.inSampleSize = (int) Math.max(
                    Math.ceil(options.outWidth / MaxAncho),
                    Math.ceil(options.outHeight / MaxAlto));
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)),null,options);
        }
        catch (FileNotFoundException e){
            Toast.makeText(contexto,"File Not Found",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
            return null;
        }
    }


    public void cambiarFecha(View view) {
        if (lugar == null) return;

        Calendar calendario = Calendar.getInstance();
        calendario.setTimeInMillis(lugar.getFecha());

        DatePickerDialog dialogoFecha = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker vista, int anyo, int mes, int dia) {
                        // Mantener la hora actual y cambiar solo la fecha
                        Calendar nuevaFecha = Calendar.getInstance();
                        nuevaFecha.setTimeInMillis(lugar.getFecha());
                        nuevaFecha.set(Calendar.YEAR, anyo);
                        nuevaFecha.set(Calendar.MONTH, mes);
                        nuevaFecha.set(Calendar.DAY_OF_MONTH, dia);

                        lugar.setFecha(nuevaFecha.getTimeInMillis());
                        Lugares.actualizarLugar((int) id, lugar);
                        actualizarVistas();

                        Toast.makeText(VistaLugar.this, "Fecha actualizada", Toast.LENGTH_SHORT).show();
                    }
                },
                calendario.get(Calendar.YEAR),
                calendario.get(Calendar.MONTH),
                calendario.get(Calendar.DAY_OF_MONTH)
        );
        dialogoFecha.show();
    }

    public void cambiarHora(View view) {
        if (lugar == null) return;

        Calendar calendario = Calendar.getInstance();
        calendario.setTimeInMillis(lugar.getFecha());

        TimePickerDialog dialogoHora = new TimePickerDialog(
                this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker vista, int hora, int minuto) {
                        // Mantener la fecha actual y cambiar solo la hora
                        Calendar nuevaHora = Calendar.getInstance();
                        nuevaHora.setTimeInMillis(lugar.getFecha());
                        nuevaHora.set(Calendar.HOUR_OF_DAY, hora);
                        nuevaHora.set(Calendar.MINUTE, minuto);

                        lugar.setFecha(nuevaHora.getTimeInMillis());
                        Lugares.actualizarLugar((int) id, lugar);
                        actualizarVistas();

                        Toast.makeText(VistaLugar.this, "Hora actualizada", Toast.LENGTH_SHORT).show();
                    }
                },
                calendario.get(Calendar.HOUR_OF_DAY),
                calendario.get(Calendar.MINUTE),
                android.text.format.DateFormat.is24HourFormat(this) // ← CORREGIDO
        );
        dialogoHora.show();
    }
}