package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class EdicionLugar extends AppCompatActivity {
    private long id;
    private Lugar lugar;
    private EditText nombre;
    private Spinner tipo;
    private EditText direccion;
    private EditText telefono;
    private EditText url;
    private EditText comentario;

    @Override
    protected void onCreate(Bundle savedInstancestate){
        super.onCreate(savedInstancestate);
        setContentView(R.layout.edicion_lugar);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Verificar que hay extras
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.e("EdicionLugar", "No se recibieron extras en el Intent");
            Toast.makeText(this, "Error: No se recibieron datos del lugar", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Obtener ID y verificar que es válido
        id = extras.getLong("id", -1);
        if (id == -1) {
            Log.e("EdicionLugar", "ID inválido recibido: " + id);
            Toast.makeText(this, "Error: ID de lugar inválido", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Obtener el lugar y verificar que existe
        lugar = Lugares.elemento((int) id);
        if (lugar == null) {
            Log.e("EdicionLugar", "No se pudo cargar el lugar con ID: " + id);
            Toast.makeText(this, "Error: No se encontró el lugar", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Log.d("EdicionLugar", "Editando lugar - ID: " + id + ", Nombre: " + lugar.getNombre());

        try {
            // Inicializar vistas
            nombre = findViewById(R.id.etNombre);
            direccion = findViewById(R.id.etDireccion);
            telefono = findViewById(R.id.etTelefono);
            url = findViewById(R.id.etUrl);
            comentario = findViewById(R.id.etComentario);
            tipo = findViewById(R.id.spinnerTipo);

            // Verificar que las vistas no son nulas
            if (nombre == null || direccion == null || telefono == null ||
                    url == null || comentario == null || tipo == null) {
                Log.e("EdicionLugar", "Una o más vistas son nulas");
                Toast.makeText(this, "Error: Problema con la interfaz", Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            // Configurar valores en las vistas
            nombre.setText(lugar.getNombre() != null ? lugar.getNombre() : "");
            direccion.setText(lugar.getDireccion() != null ? lugar.getDireccion() : "");
            telefono.setText(Integer.toString(lugar.getTelefono()));
            url.setText(lugar.getUrl() != null ? lugar.getUrl() : "");
            comentario.setText(lugar.getComentario() != null ? lugar.getComentario() : "");

            // Configurar spinner de tipos
            ArrayAdapter<String> adaptador = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_spinner_item,
                    TipoLugar.getNombre());

            adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            tipo.setAdapter(adaptador);

            // Seleccionar el tipo actual del lugar
            if (lugar.getTipo() != null) {
                tipo.setSelection(lugar.getTipo().ordinal());
            } else {
                tipo.setSelection(0); // Valor por defecto
                Log.w("EdicionLugar", "Tipo de lugar es nulo, usando valor por defecto");
            }

            Log.d("EdicionLugar", "Vistas inicializadas correctamente");

        } catch (Exception e) {
            Log.e("EdicionLugar", "Error crítico en onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error crítico al cargar la edición", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_edicion_lugar, menu);
        return true;
    }

    public void guardar(){
        lugar.setNombre(nombre.getText().toString());
        lugar.setTipo(TipoLugar.values()[tipo.getSelectedItemPosition()]);
        lugar.setDireccion(direccion.getText().toString());
        lugar.setTelefono(Integer.parseInt(telefono.getText().toString()));
        lugar.setUrl(url.getText().toString());
        lugar.setComentario(comentario.getText().toString());
        Lugares.actualizarLugar((int)id, lugar);
        finish();
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int idItem = item.getItemId();
        Log.d("EdicionLugar", "Opción seleccionada: " + idItem); // ← AÑADIR ESTA LÍNEA

        if (idItem == R.id.accion_cancelar){
            Log.d("EdicionLugar", "Cancelando - ID: " + id); // ← AÑADIR ESTA LÍNEA
            if(getIntent().getExtras().getBoolean("nuevo",false)){
                Lugares.borrar((int) id);
            }
            finish();
            return true;
        }
        if (idItem == R.id.accion_guardar){
            Log.d("EdicionLugar", "Guardando - ID: " + id); // ← AÑADIR ESTA LÍNEA
            guardar();
        }
        return super.onOptionsItemSelected(item);
    }
}