package com.example.mislugares10;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LugaresDB extends SQLiteOpenHelper {

    public LugaresDB(Context contexto){
        super(contexto,"lugares",null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS lugares ("
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "nombre TEXT, "
                + "direccion TEXT, "
                + "longitud REAL, "
                + "latitud REAL, "
                + "tipo INTEGER, "
                + "foto TEXT, "
                + "telefono INTEGER, "
                + "url TEXT, "
                + "comentario TEXT, "
                + "fecha LONG, "
                + "valoracion REAL)");
        db.execSQL("INSERT INTO lugares VALUES (null,"
                + "'El bunker de Tinchicus',"
                + "'Mercedes Sosa S/N',"
                + "-64.5750594,-32.0728125, "
                + TipoLugar.EDUCACION.ordinal()
                + ",'',1155556666,"
                + "'https://tinchicus.com',"
                + "'Un gran lugar para aprender',"
                + System.currentTimeMillis()
                + ",4.0)");
        db.execSQL("INSERT INTO lugares VALUES (null,"
                + "'El Chañar',"
                + "'Ruta Prov. 228'"
                + ",-64.5763231,-32.0709157,"
                + TipoLugar.RESTAURANTE.ordinal()
                + ",'',515273,"
                + "'https://www.elchanar.com.ar',"
                + "'Un gran lugar para comer',"
                + System.currentTimeMillis()
                + ",3.0)");
        db.execSQL("INSERT INTO lugares VALUES (null,"
                + "'Moea Moeea',"
                + "'Libertad 400',"
                + "-64.5404959,-32.0671108,"
                + TipoLugar.BAR.ordinal()
                + ",'',429992,"
                + "'https://www.moemoeea.com.ar',"
                + "'Un gran lugar para tomar algo',"
                + System.currentTimeMillis()
                + ",3.0)");
        db.execSQL("INSERT INTO lugares VALUES (null,"
                + "'Reserva Cascada Escondida',"
                + "'Camino Rural S/N',"
                + "-64.5168508,-32.0717533,"
                + TipoLugar.NATURALEZA.ordinal()
                + ",'',555666,"
                + "'https://www.starosadecalamuchita.com.ar',"
                + "'Pedazo de paraiso en la tierra',"
                + System.currentTimeMillis()
                + ",4.0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){}
}