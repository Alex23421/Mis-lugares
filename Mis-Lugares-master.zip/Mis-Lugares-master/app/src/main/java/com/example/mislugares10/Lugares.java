package com.example.mislugares10;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class Lugares {
    final static String TAG = "MisLugares";
    protected static GeoPunto posicionActual = new GeoPunto(0,0);
    protected static List< Lugar > vectorLugares = ejemploLugares();

    public Lugares(){
        vectorLugares = ejemploLugares();
    }

    public static Lugar elemento(int id){
        Log.d("Lugares", "Buscando elemento - ID: " + id); // ← AÑADIR ESTA LÍNEA

        Lugar lugar = null;
        SQLiteDatabase db = LugaresDB.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from lugares WHERE _id = ?",
                new String[]{String.valueOf(id)}); // ← Mejor usar parámetros

        if(cursor.moveToNext()){
            Log.d("Lugares", "Elemento encontrado - ID: " + id);
            lugar = new Lugar();

            // --- INICIO DE CÓDIGO AÑADIDO ---
            // Leemos todos los datos del cursor y los asignamos al objeto 'lugar'
            lugar.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("nombre")));
            lugar.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("direccion")));

            double longitud = cursor.getDouble(cursor.getColumnIndexOrThrow("longitud"));
            double latitud = cursor.getDouble(cursor.getColumnIndexOrThrow("latitud"));
            lugar.setPosicion(new GeoPunto(longitud, latitud));

            lugar.setTipo(TipoLugar.values()[cursor.getInt(cursor.getColumnIndexOrThrow("tipo"))]);
            lugar.setFoto(cursor.getString(cursor.getColumnIndexOrThrow("foto")));
            lugar.setTelefono(cursor.getInt(cursor.getColumnIndexOrThrow("telefono")));
            lugar.setUrl(cursor.getString(cursor.getColumnIndexOrThrow("url")));
            lugar.setComentario(cursor.getString(cursor.getColumnIndexOrThrow("comentario")));
            lugar.setFecha(cursor.getLong(cursor.getColumnIndexOrThrow("fecha")));
            lugar.setValoracion(cursor.getFloat(cursor.getColumnIndexOrThrow("valoracion")));
            // --- FIN DE CÓDIGO AÑADIDO ---
        } else {
            Log.e("Lugares", "Elemento NO encontrado - ID: " + id); // ← AÑADIR ESTA LÍNEA
        }

        cursor.close();
        db.close();
        return lugar;
    }

    public static void actualizarLugar(int id, Lugar lugar){
        SQLiteDatabase db = LugaresDB.getWritableDatabase();
        db.execSQL("UPDATE lugares set nombre = '" + lugar.getNombre()
                + "',direccion='" + lugar.getDireccion()
                + "',longitud=" + lugar.getPosicion().getLongitud()
                + ",latitud=" + lugar.getPosicion().getLatitud()
                + ",tipo=" + lugar.getTipo().ordinal()
                + ",foto='" + lugar.getFoto()
                + "',telefono=" + lugar .getTelefono()
                + ",url='" + lugar.getUrl()
                + "',comentario='" + lugar.getComentario()
                + "',fecha=" + lugar.getFecha()
                + ",valoracion=" + lugar.getValoracion()
                + " WHERE _id=" + id);
        db.close();
    }

    static void anyade(Lugar lugar){
        vectorLugares.add(lugar);
    }

    public static int nuevo(){
        int id = -1;
        Lugar lugar = new Lugar();
        SQLiteDatabase db = LugaresDB.getWritableDatabase();
        db.execSQL("INSERT INTO lugares (longitud,latitud,tipo,fecha) values ("
                + lugar.getPosicion().getLongitud() +","
                + lugar.getPosicion().getLatitud() + ","
                + lugar.getTipo().ordinal() + ","
                + lugar.getFecha() + ")");
        Cursor c = db.rawQuery("SELECT _id from lugares WHERE fecha ="
                + lugar.getFecha(), null );
        if (c.moveToNext())
            id = c.getInt(0);
        c.close();
        db.close();
        return id;
    }

    public static void borrar(int id) {
        Log.d("Lugares", "Ejecutando borrado - ID: " + id); // ← AÑADIR ESTA LÍNEA

        if (id < 0) {
            Log.e("Lugares", "ID inválido para borrar: " + id); // ← AÑADIR ESTA LÍNEA
            return;
        }

        try {
            SQLiteDatabase db = LugaresDB.getWritableDatabase();
            int filasAfectadas = db.delete("lugares", "_id = ?",
                    new String[]{String.valueOf(id)});
            db.close();

            Log.d("Lugares", "Filas afectadas al borrar: " + filasAfectadas); // ← AÑADIR ESTA LÍNEA

            if (filasAfectadas == 0) {
                Log.e("Lugares", "No se encontró el lugar con ID: " + id); // ← AÑADIR ESTA LÍNEA
            } else {
                Log.d("Lugares", "Lugar borrado exitosamente - ID: " + id); // ← AÑADIR ESTA LÍNEA
            }
        } catch (Exception e) {
            Log.e("Lugares", "Error al borrar lugar: " + e.getMessage()); // ← AÑADIR ESTA LÍNEA
            e.printStackTrace();
        }
    }

    public static int size() {
        return vectorLugares.size();
    }

    public static ArrayList< Lugar > ejemploLugares(){
        ArrayList < Lugar > lugares = new ArrayList < Lugar >();
        lugares.add(new Lugar("Escuela Politécnica Superior de Gandía",
                "C/ Paranimf, 1 46730 Gandia (SPAIN)", -0.166093, 38.995656,
                TipoLugar.EDUCACION, 962849300, "http://www.epsg.upv.es",
                "Uno de los mejores lugares para formarse.", 3));
        lugares.add(new Lugar("El Chañar","Ruta Prov. 228",
                -64.5404009,-32.0672181,TipoLugar.RESTAURANTE,515273,
                "https://www.elchanar.com.ar","Un gran lugar para comer",3));
        lugares.add(new Lugar("Al de siempre",
                "P.Industrial Junto Molí Nou - 46722, Benifla (Valencia)",
                -0.190642, 38.925857, TipoLugar.BAR, 636472405,
                "", "No te pierdas el arroz en calabaza.", 3));
        lugares.add(new Lugar("Barranco del Infierno",
                "Vía Verde del rio Serpis. Villalonga (Valencia)",
                -0.295058, 38.867180, TipoLugar.NATURALEZA, 0,
                "http://eosegaos.blogspot.com.es/2009/02/1orcha-villalonga-via-verde-del-rio.html",
                "Espectacular ruta para bici o andar", 4));
        lugares.add(new Lugar("La Vital",
                "Avda. La Vital, 0 46701 Gandia (Valencia)", -0.1720092,
                38.9705949, TipoLugar.COMPRAS, 962881070,
                "http://www.lavital.es/", "El típico centro comercial", 2));
        lugares.add(new Lugar("androidcurso.com", "ciberespacio",
                0.0, 0.0, TipoLugar.EDUCACION,
                962849300, "http://androidcurso.com",
                "Amplía tus conocimientos sobre Android.", 5));
        return lugares;
    }

    private static LugaresDB LugaresDB;

    public static void inicializaDB(Context contexto){
        LugaresDB = new LugaresDB(contexto);
    }

    public static Cursor listado(){
        SQLiteDatabase db = LugaresDB.getReadableDatabase();
        return db.rawQuery("SELECT * FROM lugares",null);
    }

    public static int buscarNombre(String nombre){
        int id = -1;
        SQLiteDatabase db = LugaresDB.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM lugares WHERE nombre = '"
                + nombre + "'",null);
        if(c.moveToNext()){
            id = c.getInt(0);
        }
        c.close();
        db.close();
        return id;
    }

    public static int primerId(){
        int id = -1;
        SQLiteDatabase db = LugaresDB.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT _id FROM lugares ORDER BY _id asc LIMIT 1 ",
                null);
        if (c.moveToNext()) {
            id = c.getInt(0);
        }
        c.close();
        db.close();
        return id;
    }
    public static boolean existeLugar(int id) {
        if (id < 0) return false;

        SQLiteDatabase db = LugaresDB.getReadableDatabase();
        Cursor cursor = null;
        boolean existe = false;

        try {
            cursor = db.rawQuery("SELECT _id FROM lugares WHERE _id = ?",
                    new String[]{String.valueOf(id)});
            existe = (cursor != null && cursor.moveToFirst());
        } catch (Exception e) {
            Log.e("Lugares", "Error al verificar existencia: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        Log.d("Lugares", "Verificación existencia ID " + id + ": " + existe);
        return existe;
    }

}