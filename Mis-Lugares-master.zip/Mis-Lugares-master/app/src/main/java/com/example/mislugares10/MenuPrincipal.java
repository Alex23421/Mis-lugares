package com.example.mislugares10;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        // Configurar botones
        Button btnMostrarLugares = findViewById(R.id.btnMostrarLugares);
        Button btnPreferencias = findViewById(R.id.btnPreferencias);
        Button btnAcercaDe = findViewById(R.id.btnAcercaDe);
        Button btnSalir = findViewById(R.id.btnSalir);

        // Configurar listeners
        btnMostrarLugares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuPrincipal.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnPreferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Por ahora solo un mensaje, luego lo implementaremos
                android.widget.Toast.makeText(MenuPrincipal.this, "Próximamente: Preferencias", android.widget.Toast.LENGTH_SHORT).show();
            }
        });

        btnAcercaDe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuPrincipal.this, AcercaDeMejorado.class);
                startActivity(intent);
            }
        });

        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity(); // Cierra todas las actividades y sale de la app
            }
        });
    }
}