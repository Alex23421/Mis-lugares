package com.example.mislugares10;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class Mapa extends FragmentActivity
        implements GoogleMap.OnInfoWindowClickListener, OnMapReadyCallback {

    private GoogleMap mapa;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mapa);
        ((SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapa)).getMapAsync(this);
    }

    @Override
    public void onInfoWindowClick(Marker marcador){
        int id = Lugares.buscarNombre(marcador.getTitle());
        if (id!=-1){
            Intent intento = new Intent(this,VistaLugar.class);
            intento.putExtra("id",(long)id);
            startActivityForResult(intento,0);
        }
    }

    @Override
    public void onMapReady(GoogleMap map){
        boolean primero = true;
        Cursor c = Lugares.listado();

        mapa = map;
        mapa.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mapa.setMyLocationEnabled(true);
        mapa.getUiSettings().setZoomControlsEnabled(true);
        mapa.getUiSettings().setCompassEnabled(true);

        while(c.moveToNext()){
            GeoPunto p = new GeoPunto(c.getDouble(3),c.getDouble(4));
            if (p!=null && p.getLatitud()!=0){
                if(primero){
                    mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(
                            new LatLng(p.getLatitud(),p.getLongitud()),12));
                    primero = false;
                }
                BitmapDrawable iconoDrawable = (BitmapDrawable)
                        getResources().getDrawable(TipoLugar.values()[c.getInt(5)]
                                .getRecurso());
                Bitmap iGrande = iconoDrawable.getBitmap();
                Bitmap icono = Bitmap.createScaledBitmap(iGrande,
                        iGrande.getWidth()/7,iGrande.getHeight()/7,
                        false);
                mapa.addMarker(new MarkerOptions()
                        .position(new LatLng(p.getLatitud(),p.getLongitud()))
                        .title(c.getString(1))
                        .snippet(c.getString(2))
                        .icon(BitmapDescriptorFactory.fromBitmap(icono)));
            }
        }
    }
}