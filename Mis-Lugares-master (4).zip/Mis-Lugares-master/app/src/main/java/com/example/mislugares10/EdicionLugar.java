package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class EdicionLugar extends AppCompatActivity {
    private long id;
    private Lugar lugar;
    private EditText nombre;
    private Spinner tipo;
    private EditText direccion;
    private EditText telefono;
    private EditText url;
    private EditText comentario;

    @Override
    protected void onCreate(Bundle savedInstancestate){
        super.onCreate(savedInstancestate);
        setContentView(R.layout.edicion_lugar);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Bundle extras = getIntent().getExtras();
        id = extras.getLong("id", -1);
        lugar = Lugares.elemento((int) id);
        nombre = findViewById(R.id.etNombre);
        nombre.setText(lugar.getNombre());
        direccion = findViewById(R.id.etDireccion);
        direccion.setText(lugar.getDireccion());
        telefono = findViewById(R.id.etTelefono);
        telefono.setText(Integer.toString(lugar.getTelefono()));
        url = findViewById(R.id.etUrl);
        url.setText(lugar.getUrl());
        comentario = findViewById(R.id.etComentario);
        comentario.setText(lugar.getComentario());
        tipo = findViewById(R.id.spinnerTipo);
        ArrayAdapter adaptador = new ArrayAdapter(
                this, android.R.layout.simple_spinner_item,
                TipoLugar.getNombre());
        adaptador.setDropDownViewResource(android.R.layout.
                simple_spinner_item);
        tipo.setAdapter(adaptador);
        tipo.setSelection(lugar.getTipo().ordinal());
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_edicion_lugar, menu);
        return true;
    }

    public void guardar(){
        lugar.setNombre(nombre.getText().toString());
        lugar.setTipo(TipoLugar.values()[tipo.getSelectedItemPosition()]);
        lugar.setDireccion(direccion.getText().toString());
        lugar.setTelefono(Integer.parseInt(telefono.getText().toString()));
        lugar.setUrl(url.getText().toString());
        lugar.setComentario(comentario.getText().toString());
        Lugares.actualizarLugar((int)id, lugar);
        finish();
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int idItem = item.getItemId();
        Log.d("EdicionLugar", "Opción seleccionada: " + idItem); // ← AÑADIR ESTA LÍNEA

        if (idItem == R.id.accion_cancelar){
            Log.d("EdicionLugar", "Cancelando - ID: " + id); // ← AÑADIR ESTA LÍNEA
            if(getIntent().getExtras().getBoolean("nuevo",false)){
                Lugares.borrar((int) id);
            }
            finish();
            return true;
        }
        if (idItem == R.id.accion_guardar){
            Log.d("EdicionLugar", "Guardando - ID: " + id); // ← AÑADIR ESTA LÍNEA
            guardar();
        }
        return super.onOptionsItemSelected(item);
    }
}