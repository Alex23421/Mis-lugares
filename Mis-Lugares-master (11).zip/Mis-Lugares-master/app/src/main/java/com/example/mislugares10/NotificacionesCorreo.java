package com.example.mislugares10;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class NotificacionesCorreo extends AppCompatActivity {

    private ListView listViewPreferences;
    private PreferenceAdapter adapter;
    private List<PreferenceItem> preferenceItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notificaciones_correo);

        // Configurar toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Notificaciones por correo");
        }

        initPreferenceItems();
        setupListView();
    }

    private void initPreferenceItems() {
        preferenceItems = new ArrayList<>();

        // SOLO LAS 3 OPCIONES QUE MENCIONASTE
        preferenceItems.add(new PreferenceItem(
                "recibir_correos",
                "Recibir correos",
                "Recibir correos con información comercial",
                PreferenceItem.TYPE_SWITCH
        ));

        preferenceItems.add(new PreferenceItem(
                "direccion_correo",
                "Dirección de correo",
                "Cuenta donde se mandarán las notificaciones",
                PreferenceItem.TYPE_NORMAL
        ));

        preferenceItems.add(new PreferenceItem(
                "tipos_notificaciones",
                "Tipos de notificaciones",
                "Tipos de correos que se reciben",
                PreferenceItem.TYPE_NORMAL
        ));
    }

    private void setupListView() {
        listViewPreferences = findViewById(R.id.listViewPreferences);
        adapter = new PreferenceAdapter();
        listViewPreferences.setAdapter(adapter);

        listViewPreferences.setOnItemClickListener((parent, view, position, id) -> {
            PreferenceItem item = preferenceItems.get(position);
            onPreferenceClick(item);
        });
    }

    private void onPreferenceClick(PreferenceItem item) {
        switch (item.getKey()) {
            case "direccion_correo":
                mostrarDialogoDireccionCorreo();
                break;
            case "tipos_notificaciones":
                mostrarDialogoTiposNotificaciones();
                break;
            // "recibir_correos" es un switch, se maneja automáticamente
        }
    }

    private void mostrarDialogoDireccionCorreo() {
        Toast.makeText(this, "Configurar dirección de correo", Toast.LENGTH_SHORT).show();
        // Aquí iría el diálogo para configurar el correo
    }

    private void mostrarDialogoTiposNotificaciones() {
        Toast.makeText(this, "Configurar tipos de notificaciones", Toast.LENGTH_SHORT).show();
        // Aquí iría el diálogo para seleccionar tipos
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    // Clase para representar cada item de preferencia
    private static class PreferenceItem {
        public static final int TYPE_NORMAL = 0;
        public static final int TYPE_SWITCH = 1;

        private String key;
        private String title;
        private String summary;
        private int type;
        private boolean switchValue;

        public PreferenceItem(String key, String title, String summary, int type) {
            this.key = key;
            this.title = title;
            this.summary = summary;
            this.type = type;
            this.switchValue = false;
        }

        // Getters y setters
        public String getKey() { return key; }
        public String getTitle() { return title; }
        public String getSummary() { return summary; }
        public int getType() { return type; }
        public boolean isSwitchValue() { return switchValue; }
        public void setSwitchValue(boolean value) { this.switchValue = value; }
    }

    // Adapter para la lista de preferencias
    private class PreferenceAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return preferenceItems.size();
        }

        @Override
        public Object getItem(int position) {
            return preferenceItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            return 2; // Dos tipos: normal y switch
        }

        @Override
        public int getItemViewType(int position) {
            return preferenceItems.get(position).getType();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            PreferenceItem item = preferenceItems.get(position);

            if (item.getType() == PreferenceItem.TYPE_SWITCH) {
                return createSwitchView(item, convertView, parent);
            } else {
                return createNormalView(item, convertView, parent);
            }
        }

        private View createNormalView(PreferenceItem item, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_preference, parent, false);
            }

            TextView title = convertView.findViewById(R.id.title);
            TextView summary = convertView.findViewById(R.id.summary);

            title.setText(item.getTitle());
            summary.setText(item.getSummary());

            return convertView;
        }

        private View createSwitchView(PreferenceItem item, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_preference_switch, parent, false);
            }

            TextView title = convertView.findViewById(R.id.title);
            TextView summary = convertView.findViewById(R.id.summary);
            Switch switchWidget = convertView.findViewById(R.id.switchWidget);

            title.setText(item.getTitle());
            summary.setText(item.getSummary());
            switchWidget.setChecked(item.isSwitchValue());

            // El switch maneja su propio estado
            switchWidget.setOnCheckedChangeListener((buttonView, isChecked) -> {
                item.setSwitchValue(isChecked);
                // Aquí podrías guardar la preferencia
                if (item.getKey().equals("recibir_correos")) {
                    guardarPreferenciaRecibirCorreos(isChecked);
                }
            });

            return convertView;
        }

        private void guardarPreferenciaRecibirCorreos(boolean recibir) {
            // Guardar en SharedPreferences o base de datos
            Toast.makeText(NotificacionesCorreo.this,
                    recibir ? "Recibir correos activado" : "Recibir correos desactivado",
                    Toast.LENGTH_SHORT).show();
        }
    }
}