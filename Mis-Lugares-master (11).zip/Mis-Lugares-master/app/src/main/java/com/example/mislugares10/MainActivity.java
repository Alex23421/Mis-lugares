package com.example.mislugares10;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemClickListener,
        LocationListener {

    public CursorAdapter adaptador;
    private LocationManager manejador;
    private Location mejorLocaliz;
    private VistaLugarFragment fragmentVista;

    private Cursor obtenerLugaresConLimite() {
        int maximo = Preferencias.getMaximoLugares(this);

        // CORRECCIÓN: Crear una instancia de LugaresDB
        LugaresDB dbHelper = new LugaresDB(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        return db.rawQuery("SELECT * FROM lugares ORDER BY _id DESC LIMIT " + maximo, null);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_selector);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Lugares.inicializaDB(this);
        Lugares.setContext(this);
        adaptador = new AdaptadorCursorLugares(this, obtenerLugaresConLimite());
        /* adaptador = new SimpleCursorAdapter(this,
                R.layout.elemento_lista,
                Lugares.listado(),
                new String[] { "nombre","direccion" },
                new int[] { R.id.nombre, R.id.direccion },
                0); */
        ListView listavista = (ListView) findViewById(R.id.ListaVista);
        listavista.setAdapter(adaptador);
        listavista.setOnItemClickListener(this);
        manejador = (LocationManager) getSystemService(
                LOCATION_SERVICE);
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION)==
                PackageManager.PERMISSION_GRANTED){
            if (manejador.isProviderEnabled(LocationManager.
                    GPS_PROVIDER)){
                actualizaMejorLocaliz(manejador.getLastKnownLocation(
                        LocationManager.GPS_PROVIDER));
            }
            if (manejador.isProviderEnabled(LocationManager.
                    NETWORK_PROVIDER)){
                actualizaMejorLocaliz(manejador.getLastKnownLocation(
                        LocationManager.NETWORK_PROVIDER));
            }
        } else {
            solicitarPermisoGPS();
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE)==
                PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}
                    ,0);
        }
        fragmentVista = (VistaLugarFragment) getSupportFragmentManager()
                .findFragmentById(R.id.vista_lugar_fragment);
    }

    public void solicitarPermisoGPS(){
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                0);
    }

    public void onItemClick(AdapterView<?> parent, View vista,
                            int posicion, long id){
        Intent i = new Intent(this,VistaLugar.class);
        i.putExtra("id", id);
        startActivity(i);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void lanzarAcercaDe(View view){
        Intent i = new Intent(this,AcercaDe.class);
        startActivity(i);
    }

    public void lanzarVistaLugar(View view){
        final EditText entrada = new EditText(this);
        entrada.setText("0");
        new AlertDialog.Builder(this)
                .setTitle("Seleccion del Lugar")
                .setMessage("Indica su id")
                .setView(entrada)
                .setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int whichButton) {
                                long id = Long.parseLong(entrada.getText().toString());
                                Intent i = new Intent(MainActivity.this,
                                        VistaLugar.class);
                                i.putExtra("id",id);
                                startActivity(i);
                            }
                        })
                .setNegativeButton("Cancelar",null)
                .show();
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if (id == R.id.config){
            // Cambiar esto para abrir Preferencias
            Intent intent = new Intent(MainActivity.this, Preferencias.class);
            startActivity(intent);
            return true;
        }
        if (id == R.id.buscar){
            lanzarVistaLugar(null);
            return true;
        }
        if (id == R.id.about){
            lanzarAcercaDe(null);
            return true;
        }
        if (id == R.id.menu_mapa){
            Intent intento = new Intent(this, Mapa.class);
            startActivity(intento);
            return true;
        }
        if (id == R.id.accion_nuevo) {
            long id2 = Lugares.nuevo();
            Intent i = new Intent(this, EdicionLugar.class);
            i.putExtra("nuevo", true);
            i.putExtra("id", id2);
            startActivity(i);
            return true;
        }
        // NUEVAS OPCIONES PARA EDITAR Y BORRAR DESDE EL MENÚ PRINCIPAL
        if (id == R.id.accion_editar) {
            lanzarSeleccionLugar("editar");
            return true;
        }
        if (id == R.id.accion_borrar) {
            lanzarSeleccionLugar("borrar");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // NUEVO MÉTODO PARA SELECCIONAR LUGAR
    public void lanzarSeleccionLugar(final String accion) {
        final EditText entrada = new EditText(this);
        entrada.setText("0");
        entrada.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        String titulo = "";
        String mensaje = "";

        if ("editar".equals(accion)) {
            titulo = "Editar Lugar";
            mensaje = "Ingresa el ID del lugar que quieres editar:";
        } else if ("borrar".equals(accion)) {
            titulo = "Borrar Lugar";
            mensaje = "Ingresa el ID del lugar que quieres borrar:";
        }

        new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setMessage(mensaje)
                .setView(entrada)
                .setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int whichButton) {
                        try {
                            long idSeleccionado = Long.parseLong(entrada.getText().toString());

                            // Verificar si el lugar existe
                            if (!Lugares.existeLugar((int) idSeleccionado)) {
                                Toast.makeText(MainActivity.this,
                                        "Error: No existe un lugar con ID " + idSeleccionado,
                                        Toast.LENGTH_LONG).show();
                                return;
                            }

                            if ("editar".equals(accion)) {
                                // Abrir edición
                                Intent i = new Intent(MainActivity.this, EdicionLugar.class);
                                i.putExtra("id", idSeleccionado);
                                startActivity(i);
                            } else if ("borrar".equals(accion)) {
                                // Confirmar borrado
                                confirmarBorrado(idSeleccionado);
                            }

                        } catch (NumberFormatException e) {
                            Toast.makeText(MainActivity.this,
                                    "Error: ID debe ser un número válido",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // NUEVO MÉTODO PARA CONFIRMAR BORRADO
    private void confirmarBorrado(final long id) {
        Lugar lugar = Lugares.elemento((int) id);
        String nombreLugar = (lugar != null && lugar.getNombre() != null) ?
                lugar.getNombre() : "este lugar";

        new AlertDialog.Builder(this)
                .setTitle("Confirmar Borrado")
                .setMessage("¿Estás seguro de que quieres borrar \"" + nombreLugar + "\"?")
                .setPositiveButton("Sí, borrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int whichButton) {
                        Lugares.borrar((int) id);
                        Toast.makeText(MainActivity.this,
                                "Lugar borrado exitosamente",
                                Toast.LENGTH_SHORT).show();
                        actualizaLista(); // Actualizar la lista después de borrar
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    protected void onResume(){
        super.onResume();
        activarProveedores();
    }

    private void activarProveedores(){
        if (manejador.isProviderEnabled(LocationManager.
                GPS_PROVIDER)){
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            manejador.requestLocationUpdates(LocationManager.
                    GPS_PROVIDER,20 * 1000, 5, this);
        }
        if (manejador.isProviderEnabled(LocationManager.
                NETWORK_PROVIDER)){
            manejador.requestLocationUpdates(LocationManager.
                    NETWORK_PROVIDER,10 * 1000, 10, this);
        }
    }

    @Override
    protected void onPause(){
        super.onPause();
        manejador.removeUpdates(this);
    }

    @Override
    public void onLocationChanged(Location location){
        Log.d(Lugares.TAG, "Nueva Localizacion: " + location);
        actualizaMejorLocaliz(location);
    }

    @Override
    public void onProviderDisabled(String proveedor){
        Log.d(Lugares.TAG,"Se deshabilita: " + proveedor);
        activarProveedores();
    }

    @Override
    public void onProviderEnabled(String proveedor){
        Log.d(Lugares.TAG,"Se habilita: " + proveedor);
        activarProveedores();
    }

    @Override
    public void onStatusChanged(String proveedor, int estado,
                                Bundle extras){
        Log.d(Lugares.TAG,"Cambia estado: " + proveedor);
        activarProveedores();
    }

    private static final long DOS_MINUTOS = 2 * 60 * 1000;

    private void actualizaMejorLocaliz(Location localiz){
        if(localiz != null && (mejorLocaliz == null
                || localiz.getAccuracy() < 2 * mejorLocaliz.getAccuracy()
                || localiz.getTime() - mejorLocaliz.
                getTime() > DOS_MINUTOS)) {
            Log.d(Lugares.TAG,"Nueva mejor ubicacion");
            mejorLocaliz = localiz;
            Lugares.posicionActual.setLatitud(
                    localiz.getLatitude());
            Lugares.posicionActual.setLongitud(
                    localiz.getLongitude());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("MainActivity", "onActivityResult - requestCode: " + requestCode + ", resultCode: " + resultCode); // ← AÑADIR ESTA LÍNEA

        if (resultCode == RESULT_OK) {
            actualizaLista();
        }
    }

    public void actualizaLista(){
        ListView listView = (ListView) findViewById(R.id.ListaVista);
        AdaptadorCursorLugares adaptador = (AdaptadorCursorLugares) listView.getAdapter();
        adaptador.changeCursor(obtenerLugaresConLimite());
    }

    public void muestraLugar(long id){
        if (fragmentVista != null){
            fragmentVista.actualizarVistas(id);
        } else {
            Intent intento = new Intent(this, VistaLugar.class);
            intento.putExtra("id",id);
            startActivityForResult(intento,0);
        }
    }
    private void verificarPermisosCamara() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    100);
        }
    }
}