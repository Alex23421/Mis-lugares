package com.example.mislugares10;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AcercaDeMejorado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acerca_de_mejorado);

        // Configurar el texto de acerca de
        TextView textoAcercaDe = findViewById(R.id.textoAcercaDe);
        String descripcion = "Mis Lugares - Versión 1.0\n\n" +
                "Esta aplicación ha sido desarrollada como ejemplo en el curso de Android " +
                "para demostrar cómo gestionar lugares favoritos, utilizar bases de datos SQLite, " +
                "integrar mapas de Google y trabajar con la cámara del dispositivo.\n\n" +
                "Características principales:\n" +
                "• Gestión de lugares con información detallada\n" +
                "• Base de datos local SQLite\n" +
                "• Integración con Google Maps\n" +
                "• Fotos desde cámara o galería\n" +
                "• Sistema de valoración de lugares\n" +
                "• Geolocalización y distancias\n\n" +
                "Desarrollado como proyecto educativo para el aprendizaje de desarrollo Android.";

        textoAcercaDe.setText(descripcion);
    }
}