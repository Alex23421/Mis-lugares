package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.core.content.FileProvider;

import android.text.format.DateFormat;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Calendar;
import java.util.Date;

public class VistaLugarFragment extends Fragment implements TimePickerDialog.OnTimeSetListener,
        DatePickerDialog.OnDateSetListener {
    private long id;
    private Lugar lugar;
    private Uri uriFoto;
    final static int RESULTADO_EDITAR = 2001;
    final static int RESULTADO_GALERIA = 2002;
    final static int RESULTADO_FOTO = 2003;

    @Override
    public View onCreateView(LayoutInflater inflador, ViewGroup contenedor,
                             Bundle savedInstanceState) {
        View vista = inflador.inflate(R.layout.vista_lugar, contenedor, false);
        setHasOptionsMenu(true);
        return vista;
    }

    @Override
    public void onActivityCreated(Bundle estado) {
        super.onActivityCreated(estado);
        Bundle extras = requireActivity().getIntent().getExtras();
        if (extras != null) {
            id = extras.getLong("id", -1);
            if (id != -1) actualizarVistas(id);
        }
    }

    public void actualizarVistas(final long id) {
        this.id = id;
        lugar = Lugares.elemento((int) id);
        if (lugar != null && getView() != null) {
            View v = getView();

            ((TextView) v.findViewById(R.id.nombre)).setText(lugar.getNombre());
            ((ImageView) v.findViewById(R.id.logo_tipo))
                    .setImageResource(lugar.getTipo().getRecurso());
            ((TextView) v.findViewById(R.id.tipo)).setText(lugar.getTipo().getTexto());
            ((TextView) v.findViewById(R.id.direccion)).setText(lugar.getDireccion());
            ((TextView) v.findViewById(R.id.telefono))
                    .setText(String.valueOf(lugar.getTelefono()));
            ((TextView) v.findViewById(R.id.url)).setText(lugar.getUrl());
            ((TextView) v.findViewById(R.id.comentario)).setText(lugar.getComentario());

            Date fecha = new Date(lugar.getFecha());
            ((TextView) v.findViewById(R.id.fecha))
                    .setText(android.text.format.DateFormat.getDateFormat(getContext()).format(fecha));
            ((TextView) v.findViewById(R.id.hora))
                    .setText(android.text.format.DateFormat.getTimeFormat(getContext()).format(fecha));

            RatingBar valoracion = v.findViewById(R.id.valoracion);
            valoracion.setOnRatingBarChangeListener(null);
            valoracion.setRating(lugar.getValoracion());
            valoracion.setOnRatingBarChangeListener((ratingBar, valor, fromUser) -> {
                if (fromUser) {
                    lugar.setValoracion(valor);
                    Lugares.actualizarLugar((int) id, lugar);
                }
            });

            ponerFoto(v.findViewById(R.id.foto), lugar.getFoto());
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflador) {
        inflador.inflate(R.menu.menu_vista_lugar, menu);
        super.onCreateOptionsMenu(menu, inflador);
    }

    public void lanzarBorrar() {
        Log.d("VistaLugarFragment", "Iniciando borrado - ID: " + id); // ← AÑADIR ESTA LÍNEA

        new AlertDialog.Builder(requireContext())
                .setTitle("Borrado de lugar")
                .setMessage("¿Estás seguro de querer eliminar este lugar?")
                .setPositiveButton("Ok", (dialog, cualBoton) -> {
                    Log.d("VistaLugarFragment", "Confirmado borrado - ID: " + id); // ← AÑADIR ESTA LÍNEA
                    Lugares.borrar((int) id);
                    requireActivity().finish();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public void lanzarEditarLugar() {
        Intent i = new Intent(requireActivity(), EdicionLugar.class);
        i.putExtra("id", id);
        startActivityForResult(i, RESULTADO_EDITAR);
    }

    @SuppressLint("MissingSuperCall")
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (lugar == null) return;

        if (requestCode == RESULTADO_EDITAR) {
            actualizarVistas(id);
            getView().findViewById(R.id.scrollView1).invalidate();
        } else if (requestCode == RESULTADO_FOTO && resultCode == Activity.RESULT_OK && uriFoto != null) {
            lugar.setFoto(uriFoto.toString());
            Lugares.actualizarLugar((int) id, lugar);
            ponerFoto(getView().findViewById(R.id.foto), lugar.getFoto());
        } else if (requestCode == RESULTADO_GALERIA && resultCode == Activity.RESULT_OK && data != null) {
            lugar.setFoto(data.getDataString());
            Lugares.actualizarLugar((int) id, lugar);
            ponerFoto(getView().findViewById(R.id.foto), lugar.getFoto());
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int idItem = item.getItemId();

        if (idItem == R.id.accion_compartir) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            if (lugar != null)
                intent.putExtra(Intent.EXTRA_TEXT, lugar.getNombre() + " - " + lugar.getUrl());
            startActivity(intent);
            return true;
        } else if (idItem == R.id.accion_llegar) {
            verMapa();
            return true;
        } else if (idItem == R.id.accion_borrar) {
            lanzarBorrar();
            return true;
        } else if (idItem == R.id.accion_editar) {
            lanzarEditarLugar();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    public void verMapa() {
        if (lugar == null) return;

        Uri uri;
        double lat = lugar.getPosicion().getLatitud();
        double lon = lugar.getPosicion().getLongitud();
        if (lat != 0 || lon != 0) {
            uri = Uri.parse("geo:" + lat + "," + lon);
        } else {
            uri = Uri.parse("geo:0,0?q=" + lugar.getDireccion());
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void galeria(View view) {
        try {
            // USAR ACTION_PICK para mejor compatibilidad
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");

            if (intent.resolveActivity(requireActivity().getPackageManager()) != null) {
                startActivityForResult(Intent.createChooser(intent, "Seleccionar imagen"), RESULTADO_GALERIA);
            } else {
                // Alternativa si ACTION_PICK no funciona
                Intent intentAlternativo = new Intent(Intent.ACTION_GET_CONTENT);
                intentAlternativo.setType("image/*");
                intentAlternativo.addCategory(Intent.CATEGORY_OPENABLE);

                if (intentAlternativo.resolveActivity(requireActivity().getPackageManager()) != null) {
                    startActivityForResult(Intent.createChooser(intentAlternativo, "Seleccionar imagen"), RESULTADO_GALERIA);
                } else {
                    Toast.makeText(getContext(), "No hay app de galería disponible", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            Log.e("VistaLugarFragment", "Error al abrir galería: " + e.getMessage());
            Toast.makeText(getContext(), "Error al acceder a la galería", Toast.LENGTH_LONG).show();
        }
    }

    public void tomarFoto(View view) {
        if (getContext() == null) return;

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File fotoArchivo = new File(requireContext().getExternalFilesDir(null),
                "img_" + (System.currentTimeMillis() / 1000) + ".jpg");
        uriFoto = FileProvider.getUriForFile(requireContext(),
                requireContext().getPackageName() + ".provider", fotoArchivo);

        intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFoto);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivityForResult(intent, RESULTADO_FOTO);
    }

    public void eliminarFoto(View view) {
        if (lugar == null) return;

        new AlertDialog.Builder(requireContext())
                .setTitle("Eliminación de foto")
                .setMessage("¿Estás seguro?")
                .setPositiveButton("Aceptar", (dialog, cualBoton) -> {
                    lugar.setFoto(null);
                    Lugares.actualizarLugar((int) id, lugar);
                    ponerFoto(getView().findViewById(R.id.foto), null);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    protected void ponerFoto(ImageView imageview, String uri) {
        if (uri != null && getContext() != null) {
            imageview.setImageBitmap(reduceBitmap(getContext(), uri, 1024, 1024));
        } else {
            imageview.setImageBitmap(null);
        }
    }

    public static Bitmap reduceBitmap(Context contexto, String uri, int MaxAncho, int MaxAlto){
        try {
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;

            BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)), null, options);

            // Calcular sample size de manera segura
            int sampleSize = 1;
            if (options.outWidth > MaxAncho || options.outHeight > MaxAlto) {
                final int mitadAncho = options.outWidth / 2;
                final int mitadAlto = options.outHeight / 2;

                while ((mitadAncho / sampleSize) >= MaxAncho &&
                        (mitadAlto / sampleSize) >= MaxAlto) {
                    sampleSize *= 2;
                }
            }

            options.inSampleSize = sampleSize;
            options.inJustDecodeBounds = false;

            Bitmap bitmap = BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)), null, options);

            if (bitmap == null) {
                throw new FileNotFoundException("No se pudo decodificar el bitmap");
            }

            return bitmap;

        } catch (FileNotFoundException e) {
            Log.e("reduceBitmap", "Archivo no encontrado: " + uri);
            return null;
        } catch (Exception e) {
            Log.e("reduceBitmap", "Error al procesar imagen: " + e.getMessage());
            return null;
        }
    }

    // ✅ Ahora compatible con android:onClick del XML
    public void cambiarHora(View view) {
        Toast.makeText(getContext(), "Icono hora pulsado", Toast.LENGTH_SHORT).show();
        if (lugar == null) return;

        DialogoSelectorHora dialogoHora = new DialogoSelectorHora();
        dialogoHora.setOnTimeSetListener(this);
        Bundle args = new Bundle();
        args.putLong("fecha", lugar.getFecha());
        dialogoHora.setArguments(args);
        dialogoHora.show(requireActivity().getSupportFragmentManager(), "selectorHora");
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        if (lugar == null) return;

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(lugar.getFecha());
        cal.set(Calendar.HOUR_OF_DAY, hourOfDay);
        cal.set(Calendar.MINUTE, minute);
        lugar.setFecha(cal.getTimeInMillis());
        Lugares.actualizarLugar((int) id, lugar);
        actualizarVistas(id);
    }

    public static class DialogoSelectorHora extends DialogFragment {
        private TimePickerDialog.OnTimeSetListener escuchador;

        public void setOnTimeSetListener(TimePickerDialog.OnTimeSetListener escuchador) {
            this.escuchador = escuchador;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            Calendar calendario = Calendar.getInstance();
            Bundle args = getArguments();
            if (args != null) {
                long fecha = args.getLong("fecha");
                calendario.setTimeInMillis(fecha);
            }
            int hora = calendario.get(Calendar.HOUR_OF_DAY);
            int minuto = calendario.get(Calendar.MINUTE);
            TimePickerDialog.OnTimeSetListener listener = escuchador != null ?
                    escuchador : (v, h, m) -> {
            };
            return new TimePickerDialog(getActivity(), listener, hora, minuto,
                    android.text.format.DateFormat.is24HourFormat(getActivity()));
        }
    }

    // ✅ También actualizado para funcionar con android:onClick
    public void cambiarFecha(View view) {
        Toast.makeText(getContext(), "Icono fecha pulsado", Toast.LENGTH_SHORT).show();
        if (lugar == null) return;

        DialogoSelectorFecha dialogoFecha = new DialogoSelectorFecha();
        dialogoFecha.setOnDateListener(this);
        Bundle args = new Bundle();
        args.putLong("fecha", lugar.getFecha());
        dialogoFecha.setArguments(args);
        dialogoFecha.show(requireActivity().getSupportFragmentManager(), "selectorFecha");
    }

    @Override
    public void onDateSet(DatePicker vista, int anyo, int mes, int dia) {
        if (lugar == null) return;

        Calendar calendario = Calendar.getInstance();
        calendario.setTimeInMillis(lugar.getFecha());
        calendario.set(Calendar.YEAR, anyo);
        calendario.set(Calendar.MONTH, mes);
        calendario.set(Calendar.DAY_OF_MONTH, dia);
        lugar.setFecha(calendario.getTimeInMillis());
        Lugares.actualizarLugar((int) id, lugar);

        // Actualizar la vista de fecha
        actualizarVistas(id);
    }

    public static class DialogoSelectorFecha extends DialogFragment {

        private DatePickerDialog.OnDateSetListener escuchador;

        public void setOnDateListener(DatePickerDialog.OnDateSetListener escuchador) {
            this.escuchador = escuchador;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            Calendar calendario = Calendar.getInstance();
            Bundle args = this.getArguments();
            if (args != null) {
                long fecha = args.getLong("fecha");
                calendario.setTimeInMillis(fecha);
            }
            int anyo = calendario.get(Calendar.YEAR);
            int mes = calendario.get(Calendar.MONTH);
            int dia = calendario.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), escuchador, anyo, mes, dia);
        }
    }
}
