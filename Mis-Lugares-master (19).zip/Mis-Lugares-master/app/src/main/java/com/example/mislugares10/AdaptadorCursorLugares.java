package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class AdaptadorCursorLugares extends CursorAdapter {
    private LayoutInflater inflador;
    private TextView nombre, direccion, distancia, idLugar;
    private ImageView foto;
    private RatingBar valoracion;

    public AdaptadorCursorLugares(Context contexto, Cursor c){
        super(contexto,c,false);
    }

    @Override
    public View newView(Context contexto, Cursor c, ViewGroup padre){
        inflador = (LayoutInflater) contexto
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View vista = inflador.inflate(R.layout.elemento_lista, padre, false);
        return vista;
    }

    @SuppressLint("Range")
    @Override
    public void bindView(View vista, Context contexto, Cursor c){
        // Obtener referencias a las vistas
        nombre = vista.findViewById(R.id.nombre);
        direccion = vista.findViewById(R.id.direccion);
        foto = vista.findViewById(R.id.foto);
        valoracion = vista.findViewById(R.id.valoracion);
        distancia = vista.findViewById(R.id.distancia);
        idLugar = vista.findViewById(R.id.id_lugar);

        // Establecer los valores en las vistas
        nombre.setText(c.getString(c.getColumnIndex("nombre")));
        direccion.setText(c.getString(c.getColumnIndex("direccion")));

        // MOSTRAR EL ID DEL LUGAR
        long id = c.getLong(c.getColumnIndex("_id"));
        if (idLugar != null) {
            idLugar.setText("ID: " + id);
        }

        // Configurar la imagen según el tipo de lugar
        int tipo = c.getInt(c.getColumnIndex("tipo"));
        foto.setImageResource(TipoLugar.values()[tipo].getRecurso());
        foto.setScaleType(ImageView.ScaleType.FIT_END);

        // Configurar la valoración
        valoracion.setRating(c.getFloat(c.getColumnIndex("valoracion")));

        // Calcular y mostrar la distancia
        GeoPunto posicion = new GeoPunto(
                c.getDouble(c.getColumnIndex("longitud")),
                c.getDouble(c.getColumnIndex("latitud"))
        );

        if (Lugares.posicionActual != null && posicion != null
                && posicion.getLatitud() != 0) {
            int d = (int) Lugares.posicionActual.distancia(posicion);
            if (d < 2000) {
                distancia.setText(d + " m");
            } else {
                distancia.setText((d/1000) + " km");
            }
        } else {
            distancia.setText("--");
        }
    }
}